@extends('admin.layouts.app')

@section('content')
    test
@endsection