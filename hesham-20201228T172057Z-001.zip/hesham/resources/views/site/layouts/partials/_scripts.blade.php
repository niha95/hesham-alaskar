<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="{{asset('site/assets/js/jquery-1.12.4.min.js')}}"></script>

<!-- Include all compiled plugins (below), or include individual files as needed -->

<script src="{{asset('site/assets/js/jquery.countimator.min.js')}}"></script>        <!-- Counter -->
<script src="{{asset('site/assets/js/jquery.sticky.min.js')}}"></script>             <!-- Sticky Header -->
<script src="{{asset('site/assets/js/swiper.jquery.min.js')}}"></script>             <!-- Carousel Slider -->
<script src="{{asset('site/assets/js/isotope.pkgd.min.js')}}"></script>              <!-- Isotope -->
<script src="{{asset('site/assets/js/jquery.tabslet.min.js')}}"></script>            <!-- Tabs -->
<script src="{{asset('site/assets/js/tweetie.min.js')}}"></script>                   <!-- Tweets -->
<script src="{{asset('site/assets/js/jquery.scrollUp.min.js')}}"></script>           <!-- Scroll up -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY"></script>   <!-- Google map -->
<script src="{{asset('site/assets/js/imagesloaded.pkgd.min.js')}}"></script>         <!-- Header slider scripts -->
<script src="{{asset('site/assets/js/hammer.min.js')}}"></script>
<script src="{{asset('site/assets/js/sequence.min.js')}}"></script>
<script src="{{asset('site/assets/js/venobox.min.js')}}"></script>                   <!-- Light box -->
<script src="{{asset('site/assets/js/jquery.mb.YTPlayer.min.js')}}"></script>        <!-- Video background -->
<script src="{{asset('site/assets/js/template.js')}}"></script>                      <!-- Theme Options -->

<script src="{{asset('site/assets/js/retina.js')}}"></script>                      <!-- Retina js -->
<script src="{{asset('site/assets/js/retina.min.js')}}"></script>                  <!-- Retina js -->
