<?php


return [
    'home' => 'الرئيسية',
    'about' => 'من نحن',
    'service' => 'خدماتنا',
    'blog' => 'المقالات',
    'clients' => 'عملائنا',
    'contact' => 'اتصل بنا',
];
