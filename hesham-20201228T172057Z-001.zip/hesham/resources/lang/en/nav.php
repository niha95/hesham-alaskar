<?php


return [
    'home' => 'Home',
    'about' => 'About Us',
    'service' => 'Our Services',
    'blog' => 'Blogs',
    'clients' => 'Clients',
    'contact' => 'Contact Us',
];
