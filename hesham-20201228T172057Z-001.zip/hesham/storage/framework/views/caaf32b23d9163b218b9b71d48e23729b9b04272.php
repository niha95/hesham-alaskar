<?php $__env->startSection('subheader'); ?>
    <!--begin::Info-->
    <div class="d-flex align-items-center flex-wrap mr-2">
        <!--begin::Page Title-->
        <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5"><?php echo app('translator')->get('general.blogs'); ?></h5>
        <!--end::Page Title-->
        <!--begin::Actions-->




        <!--end::Actions-->
    </div>
    <div class="d-flex align-items-center">
        <!--begin::Actions-->
        <a href="#" class="btn btn-clean btn-sm font-weight-bold font-size-base mr-1"><?php echo app('translator')->get('general.dashboard'); ?></a> <span> / </span>
        <span class="btn-clean btn-sm font-weight-bold font-size-base mr-1"><?php echo app('translator')->get('general.blogs'); ?>  </span>
        <!--end::Actions-->

    </div>
    <!--end::Info-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="card card-custom gutter-b">
        <div class="card-header flex-wrap py-3">
            <div class="card-title">
                <h3 class="card-label"><?php echo app('translator')->get('general.data'); ?>
                    <span class="d-block text-muted pt-2 font-size-sm"></span></h3>
            </div>
            <div class="card-toolbar">

                <!--begin::Button-->
                <a href="<?php echo e(route('dashboard.blogs.create')); ?>" class="btn btn-primary font-weight-bolder">
                    <i class="fas fa-plus-circle fa-sm"></i><?php echo app('translator')->get('general.add_new'); ?></a>
                <!--end::Button-->
            </div>
        </div>
        <div class="card-body">
            <!--begin: Datatable-->
            <table class="table table-bordered table-checkable" id="kt_datatable">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th><?php echo app('translator')->get('general.title'); ?></th>
                    <th><?php echo app('translator')->get('general.author'); ?></th>
                    <th><?php echo app('translator')->get('general.views'); ?></th>
                    <th><?php echo app('translator')->get('general.status'); ?></th>
                    <th><?php echo app('translator')->get('general.created_at'); ?></th>
                    <th><?php echo app('translator')->get('general.control'); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($key+1); ?></th>
                        <td><?php echo e($value->title); ?></td>
                        <td><?php echo e($value->user->name); ?></td>
                        <td><?php echo e($value->views); ?></td>
                        <td>
                            <form action="<?php echo e(route('dashboard.blog.publish',$value)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <button type="submit" class="btn btn-sm <?php if($value->status == 1): ?> btn-light-danger <?php else: ?> btn-light-success
                                <?php endif; ?> btn-icon " title="<?php echo e($value->publish); ?>">
                                    <i class="<?php if($value->status == 1): ?> far fa-times-circle  <?php else: ?> far fa-paper-plane
<?php endif; ?>"></i>
                                </button>

                            </form>
                        </td>
                        <td><?php echo e($value->created_at); ?></td>
                        <td>
                            <form class="delete-form" action="<?php echo e(route('dashboard.blogs.destroy',$value->id)); ?>"
                                  method="post">
                            <a href="<?php echo e(route('dashboard.blogs.show',$value->id)); ?>" class="btn btn-sm btn-clean
                            btn-icon mr-2" title="<?php echo app('translator')->get('general.show'); ?>">
                                <i class="fa fa-eye"></i>
                            </a>


                                <a href="<?php echo e(route('dashboard.blogs.edit',$value->id)); ?>" class="btn btn-sm btn-clean
                                btn-icon mr-2" title="<?php echo app('translator')->get('general.edit'); ?>">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="button" class="btn btn-sm btn-clean btn-icon"
                                        title="<?php echo app('translator')->get('general.delete'); ?>" onclick="confirmDelete
                                ('delete-form')">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>













                </tbody>
            </table>
            <div>
                <?php echo e($blogs->links()); ?>

            </div>

        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>