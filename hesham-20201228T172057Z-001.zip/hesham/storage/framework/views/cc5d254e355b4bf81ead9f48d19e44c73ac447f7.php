<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(asset('site/assets/js/jquery-1.12.4.min.js')); ?>"></script>

<!-- Include all compiled plugins (below), or include individual files as needed -->

<script src="<?php echo e(asset('site/assets/js/jquery.countimator.min.js')); ?>"></script>        <!-- Counter -->
<script src="<?php echo e(asset('site/assets/js/jquery.sticky.min.js')); ?>"></script>             <!-- Sticky Header -->
<script src="<?php echo e(asset('site/assets/js/swiper.jquery.min.js')); ?>"></script>             <!-- Carousel Slider -->
<script src="<?php echo e(asset('site/assets/js/isotope.pkgd.min.js')); ?>"></script>              <!-- Isotope -->
<script src="<?php echo e(asset('site/assets/js/jquery.tabslet.min.js')); ?>"></script>            <!-- Tabs -->
<script src="<?php echo e(asset('site/assets/js/tweetie.min.js')); ?>"></script>                   <!-- Tweets -->
<script src="<?php echo e(asset('site/assets/js/jquery.scrollUp.min.js')); ?>"></script>           <!-- Scroll up -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY"></script>   <!-- Google map -->
<script src="<?php echo e(asset('site/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>         <!-- Header slider scripts -->
<script src="<?php echo e(asset('site/assets/js/hammer.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/assets/js/sequence.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/assets/js/venobox.min.js')); ?>"></script>                   <!-- Light box -->
<script src="<?php echo e(asset('site/assets/js/jquery.mb.YTPlayer.min.js')); ?>"></script>        <!-- Video background -->
<script src="<?php echo e(asset('site/assets/js/template.js')); ?>"></script>                      <!-- Theme Options -->

<script src="<?php echo e(asset('site/assets/js/retina.js')); ?>"></script>                      <!-- Retina js -->
<script src="<?php echo e(asset('site/assets/js/retina.min.js')); ?>"></script>                  <!-- Retina js -->
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/partials/_scripts.blade.php ENDPATH**/ ?>