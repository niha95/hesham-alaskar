    <!-- Portfolio -->
    <div id="portfolio" class="site-portfolio site-white-section">

        <!-- Bootstrap -->
        <div class="container">
            <div class="row">
                <div class="col-xs-12">


                    <!-- H2 heading -->
                    <h2><?php echo app('translator')->get('general.rule'); ?> </h2>

                    <!-- Tabs Buttons -->

                    <!-- Bootstrap inner row -->
                    <div class="row">

                        <!-- Tabs Content -->
                        <div class="site-portfolio-tabs-content">
                            <!-- Web development -->
                            <?php $__currentLoopData = $rule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="all family portfolio-items col-sm-4 col-xs-12">
                                <!-- box -->
                                <div class="site-box">
                                    <!-- Image -->
                                    <img src="<?php echo e(asset('site/assets/images/portfolio-1.jpg')); ?>" alt="Image">
                                    <!-- Caption -->
                                    <div class="portfolio-caption">
                                        <!-- Light box open click on icon -->
                                        <a class="venobox" href="<?php echo e(asset('site/assets/images/portfolio-1-big.jpg')); ?>"  data-gall="myGallery">
                                            <i class="fa fa-plus"></i>  <!-- Icon -->
                                        </a>
                                        <h5><?php echo e($rule->name); ?></h5>    <!-- heading -->
                                        <h6><?php echo e($rule->description); ?></h6> <!-- Sub heading -->
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>

                    </div>

                    <!-- Button -->
                    <a href="#" class="theme-btn">Load More</a>

                </div>
            </div>
        </div>
        <!-- End Bootstrap -->

    </div>
    <!-- End Portfolio -->
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/partials/_rules.blade.php ENDPATH**/ ?>