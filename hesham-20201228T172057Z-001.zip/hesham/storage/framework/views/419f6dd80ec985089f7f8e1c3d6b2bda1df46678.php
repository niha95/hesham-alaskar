

 <!-- Footer -->
 <footer id="footer" class="site-footer">

    <!-- Bootstrap -->
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-3">

                <!-- Widget -->
                <div class="widget">

                    <!-- Logo -->
                    <div class="site-logo">
                        <!-- Link -->
                        <a href="index.html">
                            <!-- Logo Image -->
                            <img src="<?php echo e(asset('site/assets/images/footer-logo.png')); ?>" alt="Logo">

                        </a>
                    </div>
                    <!-- End logo -->

                    <!-- Clearfix -->
                    <div class="clearfix"></div>

                    <!-- Paragraph -->
                    <p><?php echo e($misc->site_word); ?></p>


                </div>
                <!-- End widget -->

            </div>
            <div class="col-xs-12 col-sm-6 col-md-3" >

                <!-- Widget -->
                <div class="widget">

                    <!-- H3 heading -->
                    <h3><?php echo app('translator')->get('general.lastblog'); ?></h3>

                    <!-- news -->
                    <ul class="widget-news">
                        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="#">
                                <figure><img src="<?php echo e(asset('site/assets/images/news-1.png')); ?>" alt=""></figure>
                                <p><?php echo e($blog->title); ?></p>
                                <span><?php echo e($blog->description); ?></span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
                <!-- End widget -->

            </div>
            <div class="col-xs-12 col-sm-6 col-md-3">

                <!-- Widget -->
                <div class="widget">

                    <!-- H3 heading -->
                    <h3><?php echo app('translator')->get('general.linksw'); ?></h3>

                    <!-- Links -->
                    <ul>
                        <li><a href="#"><?php echo app('translator')->get('nav.home'); ?></a></li>
                        <li><a href="#"><?php echo app('translator')->get('nav.about'); ?></a></li>
                        <li><a href="#"><?php echo app('translator')->get('nav.service'); ?></a></li>
                        <li><a href="<?php echo e($misc->links); ?>"><?php echo e($misc->links); ?> </a></li>
                    </ul>

                </div>
                <!-- End widget -->

            </div>




        </div>
    </div>
    <!-- End Bootstrap -->

    <div class="clearfix"></div>
        <div class="col-xs-12">
                <hr>
            </div>

        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6">

                <!-- Copyright -->
                <div class="site-copyright">
                    © 2020 Made by <a href="http://www.deltatiech.com/" target="_blank">Delta</a>
                </div>

            </div>
                <div class="col-xs-12 col-sm-6">

                <!-- Social Icons -->
                <div class="site-social-icons">
                    <a target="_blank" href="<?php echo e($social->fb); ?>"><i class="fa fa-facebook"></i></a>
                    <a target="_blank" href="<?php echo e($social->twitter); ?>"><i class="fa fa-twitter"></i></a>
                    <a target="_blank" href="<?php echo e($social->instagram); ?>"><i class="fa fa-instagram"></i></a>

                </div>

            </div>
            </div>
        </div>
</footer>
<!-- End Footer -->

 <!-- Preloader -->
 <div class="site-preloader">
    <img src="<?php echo e(asset('site/assets/images/loader.gif')); ?>" alt="loader">
</div>
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/partials/_footer.blade.php ENDPATH**/ ?>