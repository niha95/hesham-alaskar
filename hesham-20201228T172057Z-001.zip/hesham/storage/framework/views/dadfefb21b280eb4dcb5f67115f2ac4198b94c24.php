<?php $__env->startSection('subheader'); ?>
    <!--begin::Info-->
    <div class="d-flex align-items-center flex-wrap mr-2">
        <!--begin::Page Title-->
        <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5"><?php echo app('translator')->get('general.services'); ?></h5>
        <!--end::Page Title-->
        <!--begin::Actions-->
        <div class="subheader-separator subheader-separator-ver mt-2 mb-2 mr-4 bg-gray-200"></div>
        <span class="text-muted font-weight-bold mr-4"> </span>
        <a href="<?php echo e(route('dashboard.services.create')); ?>" class="btn btn-light-warning font-weight-bolder btn-sm"><?php echo app('translator')->get('general.add_new'); ?></a>
        <!--end::Actions-->
    </div>
    <div class="d-flex align-items-center">
        <!--begin::Actions-->
        <a href="#" class="btn btn-clean btn-sm font-weight-bold font-size-base mr-1"><?php echo app('translator')->get('general.dashboard'); ?></a> <span> / </span>
        <span class="btn-clean btn-sm font-weight-bold font-size-base mr-1"><?php echo app('translator')->get('general.services'); ?></span>
        <!--end::Actions-->

    </div>
    <!--end::Info-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-12">
    <table class="table mb-5">
        <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col"><?php echo app('translator')->get('general.name'); ?></th>
                <th scope="col"><?php echo app('translator')->get('general.description'); ?></th>
                <th scope="col"><?php echo app('translator')->get('general.icone'); ?></th>
                <th scope="col"><?php echo app('translator')->get('general.control'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key+1); ?></th>
                    <td><?php echo e($value->title); ?></td>
                    <td><?php echo e($value->description); ?></td>
                    <td><?php echo e($value->icone); ?></td>
                    <td>
                        <form class="delete-form" action="<?php echo e(route('dashboard.services.destroy',$value->id)); ?>" method="post">
                            <a href="<?php echo e(route('dashboard.services.show',$value->id)); ?>" class="btn btn-info btn-sm"> <i class="fa fa-eye fa-sm"></i>  </a>
                            <a href="<?php echo e(route('dashboard.services.edit',$value->id)); ?>" class="btn btn-primary btn-sm"> <i class="fa fa-edit fa-sm"></i>  </a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" title="delete" style="border: none; background-color:transparent;">
                                <i class="btn btn-danger btn-sm"></i>

                            </button>

                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/admin/services/index.blade.php ENDPATH**/ ?>