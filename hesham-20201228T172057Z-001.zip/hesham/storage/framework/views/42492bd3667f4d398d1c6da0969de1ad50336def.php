<?php $__env->startSection('subheader'); ?>
    <!--begin::Info-->
    <div class="d-flex align-items-center flex-wrap mr-2">
        <!--begin::Page Title-->
        <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5"><?php echo app('translator')->get('general.sliders'); ?></h5>
        <!--end::Page Title-->
        <!--begin::Actions-->
        <span class="text-muted font-weight-bold mr-4"> </span>
        <!--end::Actions-->
    </div>
    <div class="d-flex align-items-center">
        <!--begin::Actions-->
        <a href="<?php echo e(route('dashboard.sliders.index')); ?>" class="btn btn-clean btn-sm font-weight-bold
        font-size-base mr-1"><?php echo app('translator')->get('general.sliders'); ?></a> <span> / </span>
        <span class="btn-clean btn-sm font-weight-bold font-size-base mr-1"><?php echo app('translator')->get('general.show'); ?></span>
        <!--end::Actions-->

    </div>
    <!--end::Info-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <form action="#" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <div class="card card-custom mb-5">
            <div class="card-header">
             <h3 class="card-title">
                <?php echo app('translator')->get('general.data'); ?>
             </h3>
             <div class="card-toolbar">
              <div class="example-tools justify-content-center">
               <span class="example-toggle" data-toggle="tooltip" title="View code"></span>
               <span class="example-copy" data-toggle="tooltip" title="Copy code"></span>
              </div>
             </div>
            </div>
            <!--begin::Form-->


                <div class="card card-custom">
                    <div class="card-header card-header-tabs-line">
                        <div class="card-title">
                            <h3 class="card-label"><?php echo app('translator')->get('general.languages'); ?></h3>
                        </div>
                        <div class="card-toolbar">
                            <ul class="nav nav-tabs nav-bold nav-tabs-line">
                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a class="nav-link <?php if($locale == 'ar'): ?> active <?php endif; ?>" data-toggle="tab"
                                       href="<?php echo e("#" . $locale); ?>"><?php echo e(trans
                                    ('general.'.$locale . '.lang')); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade show <?php if($locale == 'ar'): ?> active <?php endif; ?>" id="<?php echo e($locale); ?>" role="tabpanel">
                                    <div class="col form-group">
                                        <label><?php echo app('translator')->get('general.' . $locale . '.title'); ?></label>
                                        <input type="text" name="<?php echo e($locale.'[title]'); ?>" id="<?php echo e($locale . '[title]'); ?>" placeholder="<?php echo app('translator')->get('general.title'); ?>" class="form-control <?php $__errorArgs = ["$locale.title" ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($slider->translate($locale)->title); ?>" required readonly>
                                        <?php $__errorArgs = ["$locale.title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col form-group">
                                        <label for="exampleTextarea"><?php echo app('translator')->get('general.' . $locale . '.description'); ?>
                                            <span class="text-danger">*</span></label>
                                        <textarea name="<?php echo e($locale.'[description]'); ?>" id="<?php echo e($locale.'[description]'); ?>" placeholder="<?php echo app('translator')->get('general.' . $locale . '.description'); ?>"
                                                  class="form-control <?php $__errorArgs = ["$locale.description" ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="5" required readonly><?php echo e($slider->translate($locale)->title); ?></textarea>
                                        <?php $__errorArgs = ["$locale.description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="col form-group">

                                        <label><?php echo app('translator')->get('general.' . $locale . '.address'); ?></label>

                                        <input type="text" name="<?php echo e($locale.'[address]'); ?>" id="<?php echo e($locale . '[address]'); ?>" placeholder="<?php echo app('translator')->get('general.address'); ?>" class="form-control <?php $__errorArgs = ["$locale.address" ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($slider->translate($locale)->title); ?>" readonly>
                                        <?php $__errorArgs = ["$locale.address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>



                    </div>
                </div>
        </div>
                    <div class="card card-custom">
                        <div class="card-body ">



                            <div class="form-group">
                                <label class="col-xl-3 col-lg-3 col-form-label"><?php echo app('translator')->get('general.image'); ?></label>
                                <div class="col-lg-9 col-xl-6">
                                    <div class="image-input image-input-outline" id="kt_image_1">
                                        <?php if(isset($slider->image)): ?>
                                            <div class="image-input-wrapper" style="background-image: url(<?php echo e($slider->image->path); ?>)"></div>
                                        <?php else: ?>
                                            <div class="image-input-wrapper" style="background-image: url(https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png)"></div>
                                        <?php endif; ?>
                                        <label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change avatar">
                                            <i class="fa fa-pen icon-sm text-muted"></i>
                                            <input type="file" name="image" accept=".png, .jpg, .jpeg" />
                                            <input type="hidden" name="profile_avatar_remove" />
                                        </label>
                                        <span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel avatar">
                                                                        <i class="ki ki-bold-close icon-xs text-muted"></i>
                                                                    </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

            </form>
            <!--end::Form-->

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/admin/sliders/show.blade.php ENDPATH**/ ?>