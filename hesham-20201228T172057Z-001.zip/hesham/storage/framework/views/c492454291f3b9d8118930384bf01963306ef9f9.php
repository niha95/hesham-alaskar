  <!-- Clients -->
  <div id="clients" class="site-clients site-dark-section">

    <!-- Bootstrap -->
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                <!-- H1 Heading -->
                <h1><?php echo app('translator')->get('general.top'); ?></h1>

                <!-- H2 heading -->
                <h2><?php echo app('translator')->get('general.topparagraph'); ?></h2>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                <!-- Images -->
                <?php $__currentLoopData = $topclient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topclient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                    <figure><a href="#"><img src="<?php echo e(asset('site/assets/images/client-1.png')); ?>" alt="<?php echo e($topclient->name); ?>"></a></figure>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
    <!-- End bootstrap -->

</div>
<!-- End clients -->
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/partials/_clients.blade.php ENDPATH**/ ?>