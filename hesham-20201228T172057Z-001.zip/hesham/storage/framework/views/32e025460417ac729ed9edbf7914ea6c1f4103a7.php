<!DOCTYPE>
<?php if(app()->getLocale() == 'ar'): ?>
<html dir="rtl">
<?php else: ?>
    <html dir="ltr">
<?php endif; ?>
<?php echo $__env->make('site.layouts.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="container-fluid page-body" >
    <div class="site-wrapper">
    <?php echo $__env->make('site.layouts.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('site.layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('site.layouts.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/default.blade.php ENDPATH**/ ?>