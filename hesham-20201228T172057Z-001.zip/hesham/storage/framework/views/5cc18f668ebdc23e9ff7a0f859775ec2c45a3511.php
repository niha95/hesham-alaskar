<div class="subheader py-2 py-lg-4 subheader-solid" id="kt_subheader">
    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">

        <?php echo $__env->yieldContent('subheader'); ?>
        
         
    </div>
</div><?php /**PATH C:\Users\pc\Documents\hesham_askar\resources\views/admin/layouts/subheader.blade.php ENDPATH**/ ?>