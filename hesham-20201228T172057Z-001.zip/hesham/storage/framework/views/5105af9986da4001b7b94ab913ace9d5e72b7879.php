
    <!-- Call to action -->
    <div class="site-call-to-action" id="call-to-action">

        <!-- Bootstrap -->
        <div class="container">
            <div class="row">
                <div class="col-xs-12">

                    <!-- Box -->
                    <div class="site-box">

                        <!-- H1 heading -->
                        <h1><?php echo app('translator')->get('general.consult'); ?></h1>

                        <!-- Bootstrap inner columns -->
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2 col-lg-offset-2">

                                <!-- Paragraph -->
                                <p><?php echo e($misc->about); ?></p>

                            </div>

                            <!-- call-info -->
                            <div class="call-info">
                                <ul>
                                    <li><a href="<?php echo e($misc->phone); ?>" > <!-- Icon --> <i class="fa fa-phone"></i> <?php echo e($misc->phone); ?> </a> </li>
                                    <li><a href="mailto:<?php echo e($social->mail); ?>" > <!-- Icon --> <i class="fa fa-envelope"></i> <?php echo e($social->mail); ?> </a> </li>
                                    <li> <i class="fa fa-clock-o"></i> <?php echo e($misc->appointment_date); ?> </li>
                                </ul>
							</div>

                            <div class="col-xs-12">

                                <!-- Button -->
                                <a href="#" class="theme-btn"> <?php echo app('translator')->get('general.consult'); ?> </a>

                            </div>
                        </div>

                    </div>
                    <!-- End box -->

                </div>
            </div>
        </div>
        <!-- End Bootstrap -->

    </div>
    <!-- End call to action -->
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/partials/_consult.blade.php ENDPATH**/ ?>