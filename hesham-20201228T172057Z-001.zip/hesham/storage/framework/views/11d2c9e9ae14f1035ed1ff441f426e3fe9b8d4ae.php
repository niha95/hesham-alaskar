<?php if(session('success')): ?>


<script type="text/javascript">
    $(function() {
      Swal.fire({
        position: "center-center",
        icon: "success",
        title: "<?php echo e(session('success')); ?>",
        showConfirmButton: false,
        timer: 1500
    });


    });

  </script>

<?php endif; ?>


<?php if(session('error')): ?>


<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'mid-center',
        showConfirmButton: false,
        timer: 1500
      });


      toastr.error("<?php echo e(session('error')); ?>")

    });

  </script>


<?php endif; ?>
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/admin/layouts/_messages.blade.php ENDPATH**/ ?>