  <!-- Services -->
  <div id="services" class="site-services site-dark-section">

    <!-- Bootstrap -->
    <div class="container">
        <div class="row">
            <div class="col-xs-12">

                <!-- H1 Heading -->
                

                <!-- H2 heading -->
                <h2><?php echo app('translator')->get('general.Our_Services'); ?></h2>

                <!-- Bootstrap inner columns -->
                <div class="row">
                    <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!-- icon box  -->
                    <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <div class="feature-box s1">
                            <!-- Icon -->
                            <figure> <img src="<?php echo e(asset('site/assets/images/home-service-icon1.png')); ?>" alt="icon"> </figure>
                            <!-- Heading -->
                            <h3><?php echo e($service->title); ?></h3>
                            <!-- Paragraph -->
                            <p><?php echo e($service->description); ?></p>


                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <!-- End Bootstrap -->

</div>
<!-- End Services -->
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/partials/_services.blade.php ENDPATH**/ ?>