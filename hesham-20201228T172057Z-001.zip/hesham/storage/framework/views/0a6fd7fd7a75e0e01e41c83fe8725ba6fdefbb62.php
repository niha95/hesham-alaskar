<?php $__env->startSection('subheader'); ?>
    <!--begin::Info-->
    <div class="d-flex align-items-center flex-wrap mr-2">
        <!--begin::Page Title-->
        <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5"><?php echo app('translator')->get('general.socials'); ?></h5>
        <!--end::Page Title-->
        <!--begin::Actions-->
        <span class="text-muted font-weight-bold mr-4"> </span>
        <!--end::Actions-->
    </div>
    <div class="d-flex align-items-center">
        <!--begin::Actions-->
        <a href="<?php echo e(route('dashboard.socials.index')); ?>" class="btn btn-clean btn-sm font-weight-bold font-size-base mr-1"><?php echo app('translator')->get('general.socials'); ?></a> <span> / </span>
        <span class="btn-clean btn-sm font-weight-bold font-size-base mr-1"><?php echo app('translator')->get('general.edit'); ?></span>
        <!--end::Actions-->

    </div>
    <!--end::Info-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-body">
      <h5 class="card-title"><?php echo app('translator')->get('general.socials'); ?></h5>
      <p class="card-text"><?php echo app('translator')->get('general.fb'); ?>: <?php echo e($social->fb); ?></p>
      <p class="card-text"><?php echo app('translator')->get('general.twitter'); ?>: <?php echo e($social->twitter); ?></p>
      <p class="card-text"><?php echo app('translator')->get('general.instagram'); ?>:<?php echo e($social->instagram); ?></p>
      <p class="card-text"><?php echo app('translator')->get('general.mail'); ?>: <?php echo e($social->mail); ?></p>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\hesham_askar\resources\views/admin/socials/show.blade.php ENDPATH**/ ?>