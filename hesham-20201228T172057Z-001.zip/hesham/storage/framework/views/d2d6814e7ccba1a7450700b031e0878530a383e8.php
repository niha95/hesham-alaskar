<!-- Testimonial -->
<div id="testimonial" class="site-testimonial site-white-section">

    <!-- Bootstrap -->
    <div class="container-fluid wide">
        <div class="row">
            <div class="col-xs-12">

                <!-- H1 heading -->

                <!-- H2 heading -->
                <h2><?php echo app('translator')->get('general.feedback'); ?></h2>

                <div class="col-xs-12 col-md-8 col-md-push-2">
                    <!-- Slider main container -->
                    <div class="swiper-container" id="testimonial-slider">
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <!-- Slides -->
                            <div class="swiper-slide">
                                <!-- Image -->
                                <figure><img src="<?php echo e(isset($client->image) ? $client->image->path : ''); ?>" alt="User"></figure>

                                <!-- Paragraph -->
                                <p><?php echo e($client->feedback); ?></p>
                                <!-- Title -->
                                <h5><?php echo e($client->name); ?></h5>
                                <!-- description -->

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                </div>

            </div>

            <div class="col-xs-12">
                <!-- If we need pagination -->
                <div id="testimonial-pagination" class="swiper-pagination"></div>
            </div>



        </div>
    </div>
    <!-- End bootstrap -->

</div>
<!-- End testimonial -->
<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/partials/_clientfeedback.blade.php ENDPATH**/ ?>