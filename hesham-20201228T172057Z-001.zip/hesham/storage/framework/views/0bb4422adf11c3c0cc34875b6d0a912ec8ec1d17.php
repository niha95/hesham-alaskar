 <!-- Top Bar -->
 <div class="site-top-bar">

    <!-- Bootstrap -->
    <div class="container">
        <div class="row">
            <div class="col-xs-12">

                <!-- Left section -->
                <div class="site-top-bar-left-section">

                    <!-- Link -->
                    <a>
                        <!-- Font awesome icon -->
                        <i class="fa fa-clock-o"></i>
                        <!-- Text -->
                        <span><?php echo e($misc->appointment_date); ?></span>
                    </a>

                </div>
                <!-- End Left Section -->


                <!-- Right Section -->
                <div class="site-top-bar-right-section">

                    <!-- Link -->
                    <a href="<?php echo e($misc->phone); ?>">
                        <!-- Icon -->
                        <i class="fa fa-phone"></i>
                        <!-- Text -->
                        <span><?php echo e($misc->phone); ?></span>
                    </a>

                    <!-- Link -->
                    <a href="mailto:<?php echo e($misc->mail); ?>">
                        <!-- Icon -->
                        <i class="fa fa-envelope"></i>
                        <!-- Text -->
                        <span><?php echo e($social->mail); ?></span>
                    </a>

                </div>
                <!-- End Right Section -->

            </div>
        </div>
    </div>
    <!-- End Bootstrap -->

</div>
<!-- End Top Bar -->
 <!-- Header -->
 <header class="site-header" id="sticky-header">

    <!-- Bootstrap -->
    <div class="container">
        <div class="row">
            <div class="col-xs-12">

                <!-- Logo -->
                <div class="site-logo">
                    <!-- Link -->
                    <a href="index.html">
                        <!-- Logo Image -->
                        <img src="<?php echo e(asset('site/assets/images/logo-icon.png')); ?>" alt="Logo">
                    </a>
                </div>
                <!-- End logo -->

                <!-- Navigation Toggle Button -->
                <div class="site-nav-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <!-- End Nav Toggle Button -->

                <!-- Navigation -->
                <nav class="site-nav">
                    <ul>
                        <!-- Active Item (Use the active class) -->
                        <li><a href="#"><?php echo app('translator')->get('nav.home'); ?> </a> <!-- Desktop sub menu indicator icon -->
                                  <!-- Mobile view sub menu indicator icon -->

                            <!-- Sub menu level 1 -->

                        <li class="active"><a href="#about"><?php echo app('translator')->get('nav.about'); ?></a></li>
                        <li><a href="#services"><?php echo app('translator')->get('nav.service'); ?></a></li>

                        <li><a href="#testimonial"><?php echo app('translator')->get('nav.clients'); ?></a></li>
                        <li><a href="#portfolio"><?php echo app('translator')->get('nav.blog'); ?></a></li>
                        
                        <li><a href="#call-to-action"><?php echo app('translator')->get('nav.contact'); ?></a></li>
                        <li>
                        <div class="btn-group">

                            <?php $__currentLoopData = Config::get('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($lang != App::getLocale()): ?>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('lang.switch', $lang)); ?>"><?php echo e($language); ?></a>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>


                        </li>
                    </ul>
                </nav>
                <!-- End Navigation -->

            </div>
        </div>
    </div>
    <!-- End Bootstrap -->

</header>
<!-- End Header -->


<?php /**PATH C:\Users\pc\Documents\hesham_askar\hesham\resources\views/site/layouts/partials/_header.blade.php ENDPATH**/ ?>