<?php

return [
    'en' => 'English',
    'ar' => 'Arabic',
];
