<?php

return
[
    'publish_ar'=>[
         0  => 'نشر',
        1   => 'الغاء النشر'
    ],

    'publish_en'=>[
        0  => 'publish',
        1   => 'UnPublish'

    ],
];
